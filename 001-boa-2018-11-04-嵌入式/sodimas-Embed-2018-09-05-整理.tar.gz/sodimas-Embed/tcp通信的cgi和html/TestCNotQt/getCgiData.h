#ifndef GETCGIDATA_H
#define GETCGIDATA_H

#include <stdio.h>
extern void getHtmlClientData(FILE *fp, char *pStr);
#endif
