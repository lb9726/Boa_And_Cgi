#!/bin/sh
arm-linux-gnueabihf-gcc *.c -o otherHtml.cgi -L. libcgic.so
